# ShuttlePro V2 Settings Files for Camtasia and Reaper #

You can read about the settings file, with images, on my blog  
http://syncor.blogspot.com/2013/06/camtasia-studio-and-shuttlepro-v2.html
Currently, these settings were for Camtasia Windows Version 8. 